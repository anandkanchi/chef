import "./globals.css";

export const metadata = {
  title: "Chef Kanchi | Bakery Operations Specialist & Consultant",
  description:
    "30+ years turning empty spaces into high-output bakery operations. Bakery setup consulting, production scaling, menu engineering, and culinary education.",
  keywords:
    "bakery consultant, bakery setup, head chef, pastry chef, culinary educator, bakery operations, India, cruise line chef",
  openGraph: {
    title: "Chef Kanchi | Bakery Operations Specialist",
    description:
      "I don't just bake. I build. 30+ years of bakery operations expertise.",
    type: "website",
    locale: "en_IN",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,300;0,400;0,500;0,700&family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500&family=Space+Mono:wght@400;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
