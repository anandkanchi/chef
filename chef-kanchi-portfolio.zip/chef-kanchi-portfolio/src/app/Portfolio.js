"use client";

import { useState, useEffect, useRef } from "react";

const WA = "https://wa.me/919949302333?text=Hello%20Chef%20Kanchi%2C%20I%20found%20your%20portfolio%20and%20would%20like%20to%20discuss%20an%20opportunity.";

// ── Data ──
const projects = [
  {
    num: "01",
    title: "The Centralized Bakery",
    subtitle: "Leading Retail Group, India",
    metric: "4,000",
    metricLabel: "breads produced daily",
    details: ["60 product menu designed from scratch", "70 member team recruited and trained", "600 kg Indian savouries daily", "Full HACCP compliant production"],
    color: "#D4A574",
  },
  {
    num: "02",
    title: "The 200 Store Scale",
    subtitle: "Major Retail Chain, India",
    metric: "200+",
    metricLabel: "stores supplied nationwide",
    details: ["Grew from 10 to 200+ outlets", "Team scaled from 30 to 200 staff", "Standardized recipes for mass production", "Post merger integration managed"],
    color: "#8B6F47",
  },
  {
    num: "03",
    title: "Seven Years at Sea",
    subtitle: "Carnival and Celebrity Cruises",
    metric: "2,000+",
    metricLabel: "guests served per sitting",
    details: ["4 contracts across 3 ships", "Promoted to Head Pastry Man", "3,500 passenger vessels", "Midnight and gala buffet production"],
    color: "#5C7A6B",
  },
  {
    num: "04",
    title: "The Sugar Free Pioneer",
    subtitle: "Specialty Bakery, India",
    metric: "800+",
    metricLabel: "pieces produced daily",
    details: ["Kitchen built from zero", "Stevia based product innovation", "12 member team trained", "Complete production unit setup"],
    color: "#9B7653",
  },
  {
    num: "05",
    title: "600+ Lives Shaped",
    subtitle: "ICI, CAI, IHM and More",
    metric: "100%",
    metricLabel: "pass rate at ICI",
    details: ["Ministry of Tourism selected faculty", "18 cruise line batches prepared", "80% placement rate achieved", "Costa Cruise Lines authorized instructor"],
    color: "#6B5B4E",
  },
];

const offerings = [
  { icon: "01", name: "Bakery Setup", text: "From empty space to full production" },
  { icon: "02", name: "Menu Engineering", text: "Recipe standardization and costing" },
  { icon: "03", name: "Production Scaling", text: "Single outlet to hundreds" },
  { icon: "04", name: "Team Building", text: "Recruit, train, and lead" },
  { icon: "05", name: "R&D Innovation", text: "New products and health lines" },
  { icon: "06", name: "Culinary Education", text: "Curriculum and programme design" },
];

const timeline = [
  { year: "1993", title: "The Beginning", org: "Holiday Inn", desc: "Night shifts baking breakfast rolls. The craft begins.", side: "left" },
  { year: "1996", title: "Set Sail", org: "Carnival Cruise Lines", desc: "First contract at sea. Learning production at a scale where 2,000 guests wait and failure is not an option.", side: "right" },
  { year: "2002", title: "Head Pastry Man", org: "Celebrity MV Mercury", desc: "Promoted to lead pastry on a 3,500-passenger vessel after 4 contracts across 3 ships. Seven years at sea complete.", side: "left" },
  { year: "2003", title: "Into Education", org: "Regency College of Hotel Management", desc: "Pioneered inter-college chocolate competition and theme restaurant concepts. 5 batches, 300 students shaped.", side: "right" },
  { year: "2006", title: "The Academy Years", org: "Culinary Academy of India", desc: "300+ students trained. 18 batches prepared for international cruise deployment. Authorized Chef Instructor for Costa Cruise Lines, Italy.", side: "left" },
  { year: "2011", title: "Sugar Free Pioneer", org: "Sweetal, Bhubaneswar", desc: "Built a production kitchen from zero. Stevia-based innovation. 800+ pieces daily with a 12-member team.", side: "right" },
  { year: "2012", title: "National Curriculum", org: "IHM Shri-Shakti (NCHMCT)", desc: "Redesigned bakery curriculum to NCHMCT standards. Chocolate making, cake decoration, crash courses for housewives.", side: "left" },
  { year: "2014", title: "The 200 Store Scale", org: "Future Retail / Big Bazaar", desc: "Scaled from 10 stores to 200+. Team grew from 30 to 200. Post-merger integration across India.", side: "right" },
  { year: "2018", title: "Ministry of Tourism", org: "Indian Culinary Institute, Tirupati", desc: "Selected by national committee. 100% pass rate, 80% placement. Served the Hon. Vice President at state inauguration.", side: "left" },
  { year: "2022", title: "The Centralized Bakery", org: "The Slice Factory (Vijetha Group)", desc: "Built the entire operation from concept to execution. 70 members, 60 products, 4,000 breads/day, 600 kg savouries/day.", side: "right" },
  { year: "Now", title: "What Comes Next", org: "Bakery Consultant", desc: "30+ years distilled into consulting. Building the next operation from nothing. Ready for the next challenge.", side: "left" },
];

const testimonials = [
  { quote: "Chef Kanchi built our entire bakery production unit from an empty warehouse. Within 3 months we were delivering 4,000 breads a day across the city.", attribution: "Production Director, Leading Retail Group" },
  { quote: "His ability to train a team from zero and instil cruise-line discipline in a commercial bakery is rare. The SOPs he created still run our operation today.", attribution: "Operations Head, National Retail Chain" },
  { quote: "100% pass rate speaks for itself. Chef Kanchi does not just teach technique. He builds professionals.", attribution: "Senior Official, Ministry of Tourism" },
];

function useInView(th = 0.2) {
  const r = useRef(null);
  const [v, setV] = useState(false);
  useEffect(() => {
    const o = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setV(true); o.disconnect(); } }, { threshold: th });
    if (r.current) o.observe(r.current);
    return () => o.disconnect();
  }, []);
  return [r, v];
}

function Reveal({ children, delay = 0, style = {} }) {
  const [r, v] = useInView(0.1);
  return (
    <div ref={r} style={{ ...style, opacity: v ? 1 : 0, transform: v ? "translateY(0)" : "translateY(40px)", transition: `all 0.9s cubic-bezier(0.16, 1, 0.3, 1) ${delay}s` }}>
      {children}
    </div>
  );
}

function Counter({ target }) {
  const [c, setC] = useState(0);
  const [r, v] = useInView();
  const n = parseInt(target.replace(/[^0-9]/g, ""));
  useEffect(() => {
    if (!v) return;
    let s = 0;
    const inc = n / 100;
    const t = setInterval(() => { s += inc; if (s >= n) { setC(n); clearInterval(t); } else setC(Math.floor(s)); }, 20);
    return () => clearInterval(t);
  }, [v, n]);
  const d = target.includes(",") ? c.toLocaleString() : c.toString();
  return <span ref={r}>{d}{target.includes("+") ? "+" : ""}{target.includes("%") ? "%" : ""}</span>;
}

function TimelineItem({ item, index }) {
  const [ref, visible] = useInView(0.15);
  const isLeft = item.side === "left";
  
  return (
    <div ref={ref} className="tl-item" style={{
      display: "flex",
      justifyContent: isLeft ? "flex-start" : "flex-end",
      paddingBottom: 0,
      opacity: visible ? 1 : 0,
      transform: visible ? "translateY(0)" : "translateY(40px)",
      transition: `all 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${index * 0.05}s`,
    }}>
      <div className="tl-card" style={{
        maxWidth: 420,
        padding: "24px 28px",
        background: "var(--card)",
        border: "1px solid var(--dim)",
        position: "relative",
        transition: "border-color 0.4s, transform 0.4s",
      }}
        onMouseEnter={e => { e.currentTarget.style.borderColor = "var(--gold)"; e.currentTarget.style.transform = "translateY(-4px)"; }}
        onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--dim)"; e.currentTarget.style.transform = "translateY(0)"; }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
          <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 11, letterSpacing: 2, color: "var(--gold)", fontWeight: 700 }}>{item.year}</span>
          <div style={{ flex: 1, height: 1, background: "var(--dim)" }} />
        </div>
        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 20, fontWeight: 600, color: "var(--cream)", marginBottom: 4 }}>{item.title}</div>
        <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 10, letterSpacing: 1, color: "var(--gold)", textTransform: "uppercase", marginBottom: 10 }}>{item.org}</div>
        <div style={{ fontSize: 13, lineHeight: 1.8, color: "var(--muted)" }}>{item.desc}</div>
      </div>
    </div>
  );
}

export default function Portfolio() {
  const [scrollY, setScrollY] = useState(0);
  const [activeProject, setActiveProject] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  useEffect(() => {
    const h = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", h, { passive: true });
    return () => window.removeEventListener("scroll", h);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial(prev => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const scrollTo = (id) => { document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }); setMenuOpen(false); };

  return (
    <div style={{ background: "#0C0A08", color: "#F5EDE3", fontFamily: "'DM Sans', sans-serif", overflowX: "hidden" }}>
      <style>{`
        /* Animations and component styles */
        
        .grain { position:fixed; top:0; left:0; width:100%; height:100%; pointer-events:none; z-index:9998; opacity:0.035;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
        }

        .marquee { display:flex; animation: scroll 20s linear infinite; }
        @keyframes scroll { from{transform:translateX(0)} to{transform:translateX(-50%)} }

        .proj-card { cursor:pointer; position:relative; padding:28px 32px; border:1px solid var(--dim); transition: all 0.5s cubic-bezier(0.16,1,0.3,1); overflow:hidden; }
        .proj-card::before { content:''; position:absolute; top:0; left:0; width:100%; height:100%; background:linear-gradient(135deg, rgba(196,151,59,0.06), transparent); opacity:0; transition:opacity 0.5s; }
        .proj-card:hover::before, .proj-card.active::before { opacity:1; }
        .proj-card:hover, .proj-card.active { border-color: var(--gold); transform: translateX(8px); }

        .offer-item { padding:24px 0; border-bottom:1px solid var(--dim); display:flex; align-items:center; gap:24px; transition: all 0.4s ease; cursor:default; }
        .offer-item:hover { padding-left:16px; border-bottom-color: var(--gold); }
        .offer-item:hover .offer-num { color: var(--gold); }

        .wa-float { position:fixed; bottom:32px; right:32px; z-index:1000; width:56px; height:56px; border-radius:50%; background:#25D366; display:flex; align-items:center; justify-content:center; text-decoration:none; box-shadow:0 4px 24px rgba(37,211,102,0.3); transition: all 0.3s; }
        .wa-float:hover { transform:scale(1.12); box-shadow:0 6px 32px rgba(37,211,102,0.5); }
        .wa-pulse { position:absolute; width:56px; height:56px; border-radius:50%; background:#25D366; animation: wap 2s infinite; }
        @keyframes wap { 0%{transform:scale(1);opacity:0.4} 100%{transform:scale(2);opacity:0} }

        .nav-item { font-family:'Space Mono',monospace; font-size:11px; letter-spacing:2px; text-transform:uppercase; color:var(--muted); text-decoration:none; cursor:pointer; transition:color 0.3s; position:relative; }
        .nav-item:hover { color:var(--gold); }
        .nav-item::after { content:''; position:absolute; bottom:-4px; left:0; width:0; height:1px; background:var(--gold); transition:width 0.3s; }
        .nav-item:hover::after { width:100%; }

        .metric-big { font-family:'Playfair Display',serif; font-size:96px; font-weight:800; line-height:0.9; color:var(--gold); }
        
        .cta-btn { font-family:'Space Mono',monospace; font-size:11px; letter-spacing:3px; text-transform:uppercase; padding:18px 44px; border:none; cursor:pointer; transition:all 0.4s cubic-bezier(0.16,1,0.3,1); position:relative; overflow:hidden; }
        .cta-btn::before { content:''; position:absolute; top:0; left:-100%; width:100%; height:100%; background:linear-gradient(90deg,transparent,rgba(255,255,255,0.1),transparent); transition:left 0.6s; }
        .cta-btn:hover::before { left:100%; }

        /* Timeline styles */
        .tl-center-line { position:absolute; left:50%; top:0; bottom:0; width:1px; background:var(--dim); transform:translateX(-50%); }
        .tl-dot { position:absolute; left:50%; width:12px; height:12px; border-radius:50%; border:2px solid var(--gold); background:var(--bg); transform:translate(-50%, 0); z-index:2; transition: background 0.3s; }
        .tl-item:hover ~ .tl-dot, .tl-dot:hover { background: var(--gold); }
        
        .tl-item .tl-card { width: 100%; }

        /* Testimonial fade */
        @keyframes fadeIn { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
        .testimonial-active { animation: fadeIn 0.6s ease forwards; }

        /* Mobile responsive */
        @media (max-width:900px) {
          .metric-big { font-size:56px !important; }
          .hero-name { font-size:44px !important; }
          .hero-tagline { font-size: 9px !important; letter-spacing: 3px !important; }
          .desk-nav { display:none !important; }
          .proj-grid { flex-direction:column !important; }
          .proj-sidebar { flex: none !important; border-right: none !important; border-bottom: 1px solid var(--dim) !important; }
          .proj-detail { min-height: auto !important; padding: 32px 24px !important; }
          .proj-detail-grid { grid-template-columns:1fr !important; }
          .offer-grid { grid-template-columns:1fr !important; }
          .footer-cols { flex-direction:column !important; gap:32px !important; align-items: flex-start !important; }
          .section-pad { padding: 80px 24px !important; }
          .section-title { font-size: 36px !important; }
          .hero-section { padding: 0 24px !important; }
          .tl-center-line { left: 20px !important; }
          .tl-item { justify-content: flex-start !important; padding-left: 48px !important; }
          .tl-dot-wrap { left: 20px !important; }
          .tl-card { max-width: 100% !important; }
          .story-ghost { display: none !important; }
          .contact-heading { font-size: 40px !important; }
          .hero-stat-grid { gap: 24px !important; }
          .hero-stat-num { font-size: 28px !important; }
        }
        @media (max-width:480px) {
          .hero-name { font-size:32px !important; }
          .metric-big { font-size:44px !important; }
          .section-title { font-size: 28px !important; }
          .section-pad { padding: 60px 16px !important; }
          .hero-section { padding: 0 16px !important; }
          .contact-heading { font-size: 28px !important; }
          .cta-btn { padding: 14px 28px !important; font-size: 10px !important; }
        }
        @media (min-width:901px) { .mob-toggle { display:none !important; } .mob-menu { display:none !important; } }
      `}</style>

      <div className="grain" />

      {/* NAV */}
      <nav style={{ position:"fixed", top:0, left:0, right:0, zIndex:100, padding:"20px 48px", display:"flex", alignItems:"center", justifyContent:"space-between", background: scrollY > 80 ? "rgba(12,10,8,0.92)" : "transparent", backdropFilter: scrollY > 80 ? "blur(16px)" : "none", transition:"all 0.4s", borderBottom: scrollY > 80 ? "1px solid rgba(58,51,44,0.5)" : "1px solid transparent" }}>
        <div style={{ cursor:"pointer" }} onClick={() => scrollTo("top")}>
          <span style={{ fontFamily:"'Playfair Display',serif", fontSize:20, fontWeight:700, color:"var(--cream)" }}>CK</span>
          <span style={{ fontFamily:"'Space Mono',monospace", fontSize:9, letterSpacing:3, color:"var(--muted)", marginLeft:12, textTransform:"uppercase" }}>Est. 1993</span>
        </div>
        <div className="desk-nav" style={{ display:"flex", gap:36 }}>
          {["Work","Services","Journey","Testimonials","Story","Contact"].map(s => <span key={s} className="nav-item" onClick={() => scrollTo(s.toLowerCase())}>{s}</span>)}
        </div>
        <div className="mob-toggle" onClick={() => setMenuOpen(!menuOpen)} style={{ color:"var(--cream)", fontSize:20, cursor:"pointer", zIndex: 101 }}>{menuOpen ? "\u2715" : "\u2630"}</div>
      </nav>
      {menuOpen && <div className="mob-menu" style={{ position:"fixed", top:0, left:0, right:0, bottom:0, zIndex:99, background:"rgba(12,10,8,0.97)", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:36 }}>
        {["Work","Services","Journey","Testimonials","Story","Contact"].map(s => <span key={s} className="nav-item" style={{ fontSize:14 }} onClick={() => scrollTo(s.toLowerCase())}>{s}</span>)}
      </div>}

      {/* HERO */}
      <section id="top" className="hero-section" style={{ minHeight:"100vh", display:"flex", flexDirection:"column", justifyContent:"center", position:"relative", padding:"0 48px", overflow:"hidden" }}>
        <div style={{ position:"absolute", top:"-20%", right:"-10%", width:"60vw", height:"60vw", borderRadius:"50%", background:"radial-gradient(circle, rgba(196,151,59,0.06) 0%, transparent 70%)", pointerEvents:"none" }} />
        <div style={{ position:"absolute", bottom:"10%", left:"-5%", width:"30vw", height:"30vw", borderRadius:"50%", background:"radial-gradient(circle, rgba(212,165,116,0.04) 0%, transparent 70%)", pointerEvents:"none" }} />

        <Reveal>
          <div className="hero-tagline" style={{ fontFamily:"'Space Mono',monospace", fontSize:11, letterSpacing:6, textTransform:"uppercase", color:"var(--gold)", marginBottom:32 }}>
            Bakery Consultant &nbsp;/&nbsp; Head Chef &nbsp;/&nbsp; Culinary Educator
          </div>
        </Reveal>
        <Reveal delay={0.15}>
          <h1 className="hero-name" style={{ fontFamily:"'Playfair Display',serif", fontSize:88, fontWeight:800, lineHeight:0.95, color:"var(--cream)", maxWidth:900, marginBottom:32 }}>
            I don't just<br />bake. I <span style={{ color:"var(--gold)", fontStyle:"italic", fontWeight:500 }}>build</span>.
          </h1>
        </Reveal>
        <Reveal delay={0.3}>
          <p style={{ fontSize:17, lineHeight:1.9, color:"var(--muted)", maxWidth:520, marginBottom:48 }}>
            30+ years turning empty spaces into high output bakery operations. From cruise ships serving thousands to centralized production lines feeding cities.
          </p>
        </Reveal>
        <Reveal delay={0.45}>
          <div style={{ display:"flex", gap:16, flexWrap:"wrap", marginBottom: 64 }}>
            <button className="cta-btn" onClick={() => scrollTo("work")} style={{ background:"var(--gold)", color:"var(--bg)" }}
              onMouseEnter={e => e.target.style.background="#DAB04E"} onMouseLeave={e => e.target.style.background="var(--gold)"}>
              View My Work
            </button>
            <button className="cta-btn" onClick={() => scrollTo("contact")} style={{ background:"transparent", color:"var(--cream)", border:"1px solid var(--dim)" }}
              onMouseEnter={e => {e.target.style.borderColor="var(--gold)";e.target.style.color="var(--gold)"}} onMouseLeave={e => {e.target.style.borderColor="var(--dim)";e.target.style.color="var(--cream)"}}>
              Let's Talk
            </button>
          </div>
        </Reveal>

        {/* Hero stats bar */}
        <Reveal delay={0.6}>
          <div className="hero-stat-grid" style={{ display: "flex", gap: 48, flexWrap: "wrap" }}>
            {[
              { num: "30+", label: "Years" },
              { num: "7", label: "Years at Sea" },
              { num: "600+", label: "Students" },
              { num: "200+", label: "Stores Scaled" },
            ].map((s, i) => (
              <div key={i}>
                <div className="hero-stat-num" style={{ fontFamily: "'Playfair Display',serif", fontSize: 36, fontWeight: 800, color: "var(--gold)", lineHeight: 1 }}>{s.num}</div>
                <div style={{ fontFamily: "'Space Mono',monospace", fontSize: 9, letterSpacing: 2, color: "var(--muted)", textTransform: "uppercase", marginTop: 4 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </Reveal>

        <div style={{ position:"absolute", bottom:48, left:48, display:"flex", alignItems:"center", gap:16 }}>
          <div style={{ width:40, height:1, background:"var(--dim)" }} />
          <span style={{ fontFamily:"'Space Mono'", fontSize:10, letterSpacing:2, color:"var(--muted)", textTransform:"uppercase" }}>Scroll to explore</span>
        </div>
      </section>

      {/* MARQUEE STRIP */}
      <div style={{ borderTop:"1px solid var(--dim)", borderBottom:"1px solid var(--dim)", padding:"16px 0", overflow:"hidden", whiteSpace:"nowrap" }}>
        <div className="marquee">
          {[...Array(2)].map((_, j) => (
            <div key={j} style={{ display:"flex", gap:0 }}>
              {["30+ Years", "7 Years at Sea", "600+ Students", "200+ Stores", "4,000 Breads/Day", "IFCA / WACS Member", "Ministry of Tourism Faculty", "Rolling Trophy Winner"].map((t, i) => (
                <span key={i} style={{ fontFamily:"'Playfair Display',serif", fontSize:15, color:"var(--muted)", padding:"0 32px", fontStyle:"italic" }}>
                  {t} <span style={{ color:"var(--gold)", margin:"0 8px" }}>{"\u2726"}</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* WORK / PROJECTS */}
      <section id="work" className="section-pad" style={{ padding:"120px 48px" }}>
        <Reveal>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end", marginBottom:64, flexWrap:"wrap", gap:24 }}>
            <div>
              <div style={{ fontFamily:"'Space Mono'", fontSize:11, letterSpacing:4, color:"var(--gold)", textTransform:"uppercase", marginBottom:12 }}>Selected Projects</div>
              <h2 className="section-title" style={{ fontFamily:"'Playfair Display',serif", fontSize:48, fontWeight:700, lineHeight:1.1 }}>What I've Built</h2>
            </div>
            <p style={{ fontSize:14, color:"var(--muted)", maxWidth:360, lineHeight:1.8 }}>Each project started with nothing. No team, no menu, no production line. Just an empty space and a vision.</p>
          </div>
        </Reveal>

        <div className="proj-grid" style={{ display:"flex", gap:0 }}>
          <div className="proj-sidebar" style={{ flex:"0 0 420px", borderRight:"1px solid var(--dim)" }}>
            {projects.map((p, i) => (
              <Reveal key={i} delay={i * 0.08}>
                <div className={`proj-card ${activeProject === i ? "active" : ""}`} onClick={() => setActiveProject(i)}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
                    <div>
                      <span style={{ fontFamily:"'Space Mono'", fontSize:10, color: activeProject === i ? "var(--gold)" : "var(--muted)", letterSpacing:2 }}>{p.num}</span>
                      <h3 style={{ fontFamily:"'Playfair Display',serif", fontSize:22, fontWeight:600, marginTop:4, color: activeProject === i ? "var(--gold)" : "var(--cream)" }}>{p.title}</h3>
                      <span style={{ fontFamily:"'DM Sans'", fontSize:12, color:"var(--muted)" }}>{p.subtitle}</span>
                    </div>
                    <span style={{ fontSize:20, color: activeProject === i ? "var(--gold)" : "var(--dim)", transition:"all 0.3s" }}>{"\u2192"}</span>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <div className="proj-detail" style={{ flex:1, minHeight:560, padding:"48px 64px", display:"flex", flexDirection:"column", justifyContent:"center", position:"relative" }}>
            <div style={{ position:"absolute", top:0, right:0, fontFamily:"'Playfair Display',serif", fontSize:200, fontWeight:800, color:"rgba(196,151,59,0.04)", lineHeight:1, pointerEvents:"none" }}>
              {projects[activeProject].num}
            </div>
            <div key={activeProject} style={{ animation:"fadeIn 0.6s ease forwards" }}>
              <div className="metric-big">
                <Counter target={projects[activeProject].metric} />
              </div>
              <div style={{ fontFamily:"'Space Mono'", fontSize:12, letterSpacing:2, color:"var(--muted)", textTransform:"uppercase", marginTop:8, marginBottom:40 }}>
                {projects[activeProject].metricLabel}
              </div>
              <div className="proj-detail-grid" style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
                {projects[activeProject].details.map((d, i) => (
                  <div key={i} style={{ padding:"16px 20px", background:"var(--card)", border:"1px solid var(--dim)", fontSize:14, color:"var(--cream)", lineHeight:1.6 }}>
                    <span style={{ color:"var(--gold)", marginRight:8, fontFamily:"'Space Mono'", fontSize:11 }}>+</span>{d}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="section-pad" style={{ padding:"120px 48px", borderTop:"1px solid var(--dim)" }}>
        <Reveal>
          <div style={{ maxWidth:1200, margin:"0 auto" }}>
            <div style={{ fontFamily:"'Space Mono'", fontSize:11, letterSpacing:4, color:"var(--gold)", textTransform:"uppercase", marginBottom:12 }}>Services</div>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end", marginBottom:64, flexWrap:"wrap", gap:24 }}>
              <h2 className="section-title" style={{ fontFamily:"'Playfair Display',serif", fontSize:48, fontWeight:700, lineHeight:1.1 }}>How I Can<br />Help You</h2>
              <p style={{ fontSize:14, color:"var(--muted)", maxWidth:400, lineHeight:1.8 }}>Three decades of knowledge distilled into actionable consulting. I bring the same rigour that fed 2,000 guests a night on cruise ships to your bakery operation.</p>
            </div>
          </div>
        </Reveal>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div className="offer-grid" style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"0 80px" }}>
            {offerings.map((o, i) => (
              <Reveal key={i} delay={i * 0.06}>
                <div className="offer-item">
                  <span className="offer-num" style={{ fontFamily:"'Space Mono'", fontSize:11, color:"var(--dim)", letterSpacing:2, transition:"color 0.3s", minWidth:28 }}>{o.icon}</span>
                  <div>
                    <div style={{ fontFamily:"'Playfair Display',serif", fontSize:22, fontWeight:600, marginBottom:4 }}>{o.name}</div>
                    <div style={{ fontSize:13, color:"var(--muted)" }}>{o.text}</div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* PROFESSIONAL TIMELINE / JOURNEY */}
      <section id="journey" className="section-pad" style={{ padding:"120px 48px", borderTop:"1px solid var(--dim)" }}>
        <Reveal>
          <div style={{ textAlign: "center", marginBottom: 80 }}>
            <div style={{ fontFamily:"'Space Mono'", fontSize:11, letterSpacing:4, color:"var(--gold)", textTransform:"uppercase", marginBottom:12 }}>The Journey</div>
            <h2 className="section-title" style={{ fontFamily:"'Playfair Display',serif", fontSize:48, fontWeight:700, lineHeight:1.1 }}>30 Years of<br />Building from Zero</h2>
          </div>
        </Reveal>

        <div style={{ maxWidth: 960, margin: "0 auto", position: "relative" }}>
          {/* Center line */}
          <div className="tl-center-line" />
          
          {timeline.map((item, i) => (
            <div key={i} style={{ position: "relative", marginBottom: 24 }}>
              {/* Dot on center line */}
              <div className="tl-dot-wrap" style={{ position: "absolute", left: "50%", top: 28, zIndex: 2 }}>
                <div style={{ width: 12, height: 12, borderRadius: "50%", border: "2px solid var(--gold)", background: "var(--bg)", transform: "translateX(-50%)" }} />
              </div>
              
              {/* Card */}
              <div className="tl-item" style={{
                display: "flex",
                justifyContent: item.side === "left" ? "flex-start" : "flex-end",
                paddingLeft: item.side === "left" ? 0 : "calc(50% + 32px)",
                paddingRight: item.side === "right" ? 0 : "calc(50% + 32px)",
              }}>
                <TimelineItem item={item} index={i} />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section id="testimonials" className="section-pad" style={{ padding:"120px 48px", borderTop:"1px solid var(--dim)", position: "relative", overflow: "hidden" }}>
        <div style={{ position:"absolute", top:"50%", left:"5%", transform:"translateY(-50%)", fontFamily:"'Playfair Display',serif", fontSize:300, fontWeight:800, color:"rgba(196,151,59,0.02)", lineHeight:1, pointerEvents:"none" }}>"</div>
        
        <div style={{ maxWidth: 700, margin: "0 auto", textAlign: "center" }}>
          <Reveal>
            <div style={{ fontFamily:"'Space Mono'", fontSize:11, letterSpacing:4, color:"var(--gold)", textTransform:"uppercase", marginBottom:12 }}>Testimonials</div>
            <h2 className="section-title" style={{ fontFamily:"'Playfair Display',serif", fontSize:48, fontWeight:700, lineHeight:1.1, marginBottom: 64 }}>What They Say</h2>
          </Reveal>
          
          <div style={{ minHeight: 200 }}>
            <div key={activeTestimonial} className="testimonial-active">
              <div style={{ fontFamily:"'Playfair Display',serif", fontSize:24, fontWeight:400, fontStyle:"italic", lineHeight:1.7, color:"var(--cream)", marginBottom:32 }}>
                "{testimonials[activeTestimonial].quote}"
              </div>
              <div style={{ fontFamily:"'Space Mono',monospace", fontSize:10, letterSpacing:2, color:"var(--gold)", textTransform:"uppercase" }}>
                {testimonials[activeTestimonial].attribution}
              </div>
            </div>
          </div>

          {/* Dots */}
          <div style={{ display:"flex", gap:8, justifyContent:"center", marginTop:40 }}>
            {testimonials.map((_, i) => (
              <div key={i} onClick={() => setActiveTestimonial(i)} style={{
                width: activeTestimonial === i ? 24 : 8,
                height: 8,
                borderRadius: 4,
                background: activeTestimonial === i ? "var(--gold)" : "var(--dim)",
                cursor: "pointer",
                transition: "all 0.4s cubic-bezier(0.16,1,0.3,1)"
              }} />
            ))}
          </div>
        </div>
      </section>

      {/* STORY */}
      <section id="story" className="section-pad" style={{ padding:"120px 48px", borderTop:"1px solid var(--dim)", position:"relative" }}>
        <div className="story-ghost" style={{ position:"absolute", top:"50%", right:"5%", transform:"translateY(-50%)", fontFamily:"'Playfair Display',serif", fontSize:300, fontWeight:800, color:"rgba(196,151,59,0.025)", lineHeight:1, pointerEvents:"none" }}>30</div>
        <div style={{ maxWidth:700, margin:"0 auto" }}>
          <Reveal>
            <div style={{ fontFamily:"'Space Mono'", fontSize:11, letterSpacing:4, color:"var(--gold)", textTransform:"uppercase", marginBottom:12 }}>The Story</div>
            <h2 className="section-title" style={{ fontFamily:"'Playfair Display',serif", fontSize:48, fontWeight:700, lineHeight:1.1, marginBottom:48 }}>From Holiday Inn<br />to Head Chef</h2>
          </Reveal>
          <Reveal delay={0.15}>
            <p style={{ fontSize:17, lineHeight:2.1, color:"var(--muted)", marginBottom:32 }}>
              It started in 1993 at a Holiday Inn, on night shifts baking breakfast rolls. By 1996, I was at sea on Carnival Cruise Lines, learning what it means to produce at scale when 2,000 guests are waiting and failure isn't an option.
            </p>
          </Reveal>
          <Reveal delay={0.25}>
            <p style={{ fontSize:17, lineHeight:2.1, color:"var(--muted)", marginBottom:32 }}>
              Seven years and four contracts later, I carried that discipline back to land. I trained 300+ students at the Culinary Academy of India, prepared 18 batches for international cruise deployment, and was authorized as a Chef Instructor by Costa Cruise Lines, Italy.
            </p>
          </Reveal>
          <Reveal delay={0.35}>
            <p style={{ fontSize:17, lineHeight:2.1, color:"var(--muted)", marginBottom:32 }}>
              The Ministry of Tourism selected me for the Indian Culinary Institute, where I achieved a 100% pass rate and 80% student placement. I was invited by protocol to serve the Hon. Vice President and the Chief Minister at official state inaugurations.
            </p>
          </Reveal>
          <Reveal delay={0.45}>
            <p style={{ fontSize:17, lineHeight:2.1, color:"var(--cream)", marginBottom:48 }}>
              Today, I build bakeries from nothing. Twice, I've transformed an empty warehouse into a production powerhouse. That's not just my career. That's my craft.
            </p>
          </Reveal>
          <Reveal delay={0.55}>
            <div style={{ display:"flex", flexWrap:"wrap", gap:12 }}>
              {["IFCA / WACS Life Member", "Rolling Trophy 2004", "Zee TV Host", "ACP Executive Committee", "CFTRI Certified", "Train the Trainers (USA)"].map((t, i) => (
                <span key={i} style={{ fontFamily:"'Space Mono'", fontSize:10, letterSpacing:2, textTransform:"uppercase", padding:"8px 16px", border:"1px solid var(--dim)", color:"var(--muted)", transition:"all 0.3s" }}
                  onMouseEnter={e => {e.target.style.borderColor="var(--gold)";e.target.style.color="var(--gold)"}}
                  onMouseLeave={e => {e.target.style.borderColor="var(--dim)";e.target.style.color="var(--muted)"}}>
                  {t}
                </span>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="section-pad" style={{ padding:"120px 48px", borderTop:"1px solid var(--dim)", position:"relative", overflow:"hidden" }}>
        <div style={{ position:"absolute", top:"-10%", left:"50%", transform:"translateX(-50%)", width:"60vw", height:"60vw", borderRadius:"50%", background:"radial-gradient(circle, rgba(196,151,59,0.04) 0%, transparent 60%)", pointerEvents:"none" }} />
        <div style={{ maxWidth:800, margin:"0 auto", textAlign:"center", position:"relative", zIndex:2 }}>
          <Reveal>
            <div style={{ fontFamily:"'Space Mono'", fontSize:11, letterSpacing:4, color:"var(--gold)", textTransform:"uppercase", marginBottom:16 }}>Start a Project</div>
            <h2 className="contact-heading" style={{ fontFamily:"'Playfair Display',serif", fontSize:56, fontWeight:700, lineHeight:1.05, marginBottom:24 }}>
              Let's build<br />something <span style={{ color:"var(--gold)", fontStyle:"italic" }}>extraordinary</span>
            </h2>
            <p style={{ fontSize:16, lineHeight:1.9, color:"var(--muted)", maxWidth:480, margin:"0 auto 48px" }}>
              Whether it's a bakery launch, a production overhaul, or a team that needs training, I bring the expertise of 30 years and the precision of cruise line kitchens.
            </p>
          </Reveal>
          <Reveal delay={0.2}>
            <div style={{ display:"flex", gap:16, justifyContent:"center", flexWrap:"wrap", marginBottom:48 }}>
              <a href={WA} target="_blank" rel="noopener noreferrer" className="cta-btn" style={{ background:"#25D366", color:"#fff", textDecoration:"none", display:"inline-flex", alignItems:"center", gap:10 }}
                onMouseEnter={e => e.currentTarget.style.background="#1DA851"} onMouseLeave={e => e.currentTarget.style.background="#25D366"}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                WhatsApp
              </a>
              <a href="mailto:chefkanchi@gmail.com" className="cta-btn" style={{ background:"transparent", color:"var(--cream)", border:"1px solid var(--dim)", textDecoration:"none" }}
                onMouseEnter={e => {e.currentTarget.style.borderColor="var(--gold)";e.currentTarget.style.color="var(--gold)"}} onMouseLeave={e => {e.currentTarget.style.borderColor="var(--dim)";e.currentTarget.style.color="var(--cream)"}}>
                chefkanchi@gmail.com
              </a>
            </div>
          </Reveal>
          <Reveal delay={0.3}>
            <div style={{ fontFamily:"'DM Sans'", fontSize:13, color:"var(--muted)" }}>India &nbsp;·&nbsp; Open to relocation worldwide</div>
          </Reveal>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ padding:"48px 48px 36px", borderTop:"1px solid var(--dim)" }}>
        <div className="footer-cols" style={{ maxWidth:1200, margin:"0 auto", display:"flex", justifyContent:"space-between", alignItems:"flex-end" }}>
          <div>
            <span style={{ fontFamily:"'Playfair Display',serif", fontSize:24, fontWeight:700 }}>Chef Kanchi</span>
            <div style={{ fontFamily:"'Space Mono'", fontSize:10, letterSpacing:2, color:"var(--muted)", textTransform:"uppercase", marginTop:8 }}>{"\u00A9"} 2026. All rights reserved.</div>
          </div>
          <div style={{ display:"flex", gap:32 }}>
            {["Work","Services","Journey","Story","Contact"].map(s => <span key={s} className="nav-item" onClick={() => scrollTo(s.toLowerCase())}>{s}</span>)}
          </div>
        </div>
      </footer>

      {/* WHATSAPP FLOAT */}
      <a href={WA} target="_blank" rel="noopener noreferrer" className="wa-float">
        <div className="wa-pulse" />
        <svg width="28" height="28" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
      </a>
    </div>
  );
}
